README CMSPROJECT TEAM X
~
~
-You must first import the cmsdb.sql database. We used XAMPP and phpmyadmin for this.
-Make sure the database is named cmsdb
-Double click CRM_FAF.jar to run project